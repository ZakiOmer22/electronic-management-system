<footer class="footer footer-alt">
            2020 - <?php echo date ('Y');?> &copy; Electronic Management System.</a> 
</footer>
